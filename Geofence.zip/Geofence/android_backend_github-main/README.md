"# SSL4" 
# Android Backend Node.js Project
this is written to provide steps to setup and run server for geofencing app.
## Prerequisites
* Node.js
* npm
## Installation
1. Clone the repository:
2. Goto folder having these files
3. run command "npm install"
4. run command "node app.js"
